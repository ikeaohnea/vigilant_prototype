<template>
<div class="container">
  <div class="header">
    <img src="@/assets/Vigilant_Icon_red.png" alt="Vigilant Logo">
    <h1>vigilant</h1>
  </div>
  <div class= "networks">
    <p>Select News Network:</p>
    <p>
      <button v-on:click="">BBC One</button>
      <button v-on:click="">Daily Mail</button>
      <button v-on:click="">Telegraph</button>
      <button v-on:click="">CNN</button>
      <button v-on:click="">The Guardian</button>
      <button v-on:click="">Fox News</button>
      <button v-on:click="">New York Times</button>
      <button v-on:click="">Economist</button>
      <button v-on:click="">Washington Post</button>
      <button v-on:click="">Euronews</button>
    </p>
    <p class="date">Select Date:</p>
    <!-- insert date picker -->
  </div> 
  <div class= "wordsearch">
      <p>
        <svg  xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
          <path id="Icon_open-magnifying-glass" data-name="Icon open-magnifying-glass" d="M8.671-.02a8.671,8.671,0,1,0,0,17.343,8.571,8.571,0,0,0,4.113-1.016,2.478,2.478,0,0,0,.322.322l2.478,2.478a2.527,2.527,0,1,0,3.568-3.568l-2.478-2.478a2.478,2.478,0,0,0-.4-.322,8.555,8.555,0,0,0,1.09-4.113A8.681,8.681,0,0,0,8.7-.045Zm0,2.478a6.165,6.165,0,0,1,6.194,6.194,6.213,6.213,0,0,1-1.635,4.261l-.074.074a2.477,2.477,0,0,0-.322.322A6.2,6.2,0,0,1,8.647,14.87a6.194,6.194,0,1,1,0-12.388Z" transform="translate(0 0.045)"/>
      </svg>
        <label for="">Search for the following term:</label><input name=""  type="" placeholder="Search">
      </p>
    </div>
    <div class= "articles">
          <p>Select Article:</p>
  </div>
</div>
<footer>
<div>© Vigilant 2021 - CDCLab WS20/Practical Software Development & Applied AI</div>
</footer>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
  
    }
  },
  methods: {
    
    },
  }
</script>

<style>
*{
  margin: 0;
	padding: 0;
	border: none;
  cursor: default;
}
@font-face {
  font-family: "Woodford Bourne";
  src: local("Woodford_Bourne"),   url(./assets/Woodford_Bourne/woodfordbourne-regular.otf) format("truetype");
  }
.container{
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-areas: 
        "h h"
        "n w"
        "n a";
  text-align: center;
}
#app {
  font-family: Helvetica, sans-serif;
}
.header{
  grid-area: h;
  background-color: black;
  height: 6rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
img{
  width: 54px;
  height: 63px;
  float: left;
  padding: 0 10px 0 0;
}
h1{
  font-size: 36px;
  text-transform: uppercase;
  color: white;
  letter-spacing: 5px;
  text-align: center;
  /* top: 50%;
  left: 50%;
  margin-right: -50%;
  transform: translate(-50%, -50%) */
}
.networks{
  grid-area: n;
  padding: 80px;
}
.wordsearch{
  grid-area: w;
  background-color: #E2E9EA;
  padding: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 80px;
}
::placeholder {
  color: grey;
  font-size: 0.8em;
}
.wordsearch p{
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.articles{
  grid-area: a;
  background-color: #CBD9D9;
  padding: 80px;
  height: 300px;
}
p{
  font-size: 20px;
  font-family: "Woodford Bourne", Helvetica, sans-serif;
  padding: 10px 0 10px 0;
}
label{
  padding: 0;
}
.date{
  padding: 80px;
}
input {
 cursor: text;
 width: 200px;
 /* display: inline-block; */
 border: 1px solid #cfd4db;
 border-radius: 2rem;
 font-size: 20px;
 line-height: 2rem;
 padding: 0 .5rem 0 2rem;
 outline: none;
 transition: all .2s ease;
 background-size: auto;
 background-size: 1rem;
}
svg{
  /* float: left; */
  padding: 0;
}
button {
  border-radius: 4%;
  cursor: pointer;
  margin: 5px;
  font-size: 17px;
  padding: 3px 10px 3px 10px;
  background-color: #CBD9D9;
  justify-content: center;
}
button :visited {
  background-color: orange;
  }
footer div{
  color: white;
  text-align: center;
  font-size: 15px;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-right: -50%;
  transform: translate(-50%, -50%)  
}
footer{
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 40px;
  background-color:#2E4950;

}
</style>
